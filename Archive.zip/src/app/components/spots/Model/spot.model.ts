export class Spot {
  public AccountID: number;
  public Spot: string;
  public StartDate: string;
  public EndDate: string;
}