namespace WebAPI.Models {
    public class ReturnResponse {
        public bool success {get; set; }
        public string message {get; set;}
        public string reference {get;set;}
    }
}